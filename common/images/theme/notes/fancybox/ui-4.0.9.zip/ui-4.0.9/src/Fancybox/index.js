import { Panzoom } from "../Panzoom/Panzoom.js";
import { Carousel } from "../Carousel/Carousel.js";
import { Fancybox } from "./Fancybox.js";

export { Fancybox, Carousel, Panzoom };
