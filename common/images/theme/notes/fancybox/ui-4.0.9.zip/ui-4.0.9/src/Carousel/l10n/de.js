export default {
  NEXT: "Nächste Folie",
  PREV: "Vorherige Folie",
  GOTO: "Zur #%d Folie gehen",
};
