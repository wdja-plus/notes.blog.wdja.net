import { Panzoom } from "../Panzoom/Panzoom.js";
import { Carousel } from "../Carousel/Carousel.js";
import { Fancybox } from "./Fancybox/Fancybox.js";

export { Panzoom, Carousel, Fancybox };
